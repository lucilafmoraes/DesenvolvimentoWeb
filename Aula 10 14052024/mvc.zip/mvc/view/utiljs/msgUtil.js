export function exibirMensagemDeErro(msg){
    document.querySelector('#msgErro').textContent = msg;
    return;
}